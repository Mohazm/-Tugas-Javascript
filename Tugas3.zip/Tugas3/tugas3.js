// Alert
alert("selamat Datang!!!");

// confirm
var username = document.getElementById("tombol");
function checker(){
    var result = confirm('Are you sure?')
    if (result == false)  {
        event.preventDefault();
    }
}


// prompt
function angka(){
    var nomor = prompt("Isi angka Yang tepat!!!" );
    if(nomor == "2") {
        alert("Benar Angka "  + nomor );
    }
    else{
        alert("Salah masukkan angka, Bukan angka " + nomor );
    }
}
