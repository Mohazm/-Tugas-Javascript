let tugas = document.getElementById("tugas")
let tugas1 = document.getElementById("tugas1")
let tugas2 = document.getElementById("tugas2")
let tugas3 = document.getElementById("tugas3")
let tugas4 = document.getElementById("tugas4")

// Original
let teks ="Merah Putih" 
tugas.innerText = "sebelum diubah : " + teks

// Di ubah ke Upper
let kapital = teks.toUpperCase()
tugas1.innerText = "Sesudah di ubah ke Upper : " + kapital

// Di ubah ke Lower
let low = kapital.toLocaleLowerCase()
tugas2.innerText = "sesudah di ubah ke lower : " + low

// Di ubah ke replace
let rep = teks.replace("Putih","Muda")
tugas3.innerText = "sesudah di ubah ke replace : " + rep

// Di ubah ke length
let panjang = rep.length;
tugas4.innerText = "sesudah di ubah ke length : " + panjang
