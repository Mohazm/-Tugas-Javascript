let angka = prompt("Masukkan Bilangan")

function bilangan(){
    var nomor = prompt("Masukkan Bilangan" )
    if (angka % 2 === 0) {
        alert(angka + " " + "Adalah bilangan Genap")
    } else {
        alert(angka + " " + "Adalah Bilangan Ganjil")
    }
}
