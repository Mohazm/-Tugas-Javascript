const kalkulator = () => {
    let operator = document.getElementById("operator").value
    let angka1 = parseInt(document.getElementById("angka1").value)
    let angka2 = parseInt(document.getElementById("angka2").value)
    let hasil = document.getElementById("hasil")

    if (operator == "penjumlahan") {
        hasil.innerText = angka1 + angka2
        return hasil
    }
    else if (operator == "pengurangan") {
        hasil.innerText = angka1 - angka2
        return hasil
    }
    else if (operator == "perkalian") {
        hasil.innerText = angka1 * angka2
        return hasil
    }
    else if (operator == "pembagian") {
        hasil.innerText = angka1 / angka2
        return hasil
    }
}