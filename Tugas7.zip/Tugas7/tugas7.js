

let array = document.getElementById("array")

const getArray = () => {
    let tugas = document.getElementById("tugas")
    let tugas1 = document.getElementById("tugas1")
    let tugas2 = document.getElementById("tugas2")

    let tugas3 = document.getElementById("tugas3")

    let binatang = [
        'Gajah',
        'Ikan',
        'Harimau',
    ]
    tugas.innerHTML = binatang
    binatang.push("Gagak")
    tugas1.innerHTML = binatang

    for (h of binatang) {
        console.log(binatang)
    }

    tugas1.innerHTMl = binatang
    binatang[2] = "Kucing"
    tugas2.innerHTML = binatang

    tugas2.innerHTMl = binatang
    binatang.shift([0])
    tugas3.innerHTML = binatang



}

getArray()


